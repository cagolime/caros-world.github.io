# 📖 BLANK TEMPLATE - COMPLETE EDITING GUIDE
## Edit EVERYTHING Without Touching Code!

---

## 🔐 STEP 1: CHANGE YOUR PASSWORD (DO THIS FIRST!)

1. Right-click `pocky-blank-template.html` → Open With → Notepad (Windows) or TextEdit (Mac)
2. Press **Ctrl+F** (or **Cmd+F** on Mac)
3. Search for: `pocky2024`
4. You'll see: `const ADMIN_PASSWORD = 'pocky2024';`
5. Change `pocky2024` to YOUR password
6. **Save** the file (Ctrl+S or Cmd+S)
7. Close Notepad/TextEdit

⚠️ **WRITE DOWN YOUR PASSWORD!** This protects your admin panel.

---

## 🎨 WHAT CAN YOU EDIT?

### ✅ EVERYTHING! Including:
- **Header** (main title, subtitle, corner text)
- **All page titles** (Introduction, Updates, About, Rules, etc.)
- **All page content** (every single text box)
- **Join form labels** (name, email, custom fields)
- **Navigation links** (about, rules, codes, join, members, site, clear)
- **Updates** (with images!)

### ❌ You CANNOT Edit (Without Code):
- Colors and background
- Layout and spacing
- Navigation order
- Font styles

---

## 🚀 HOW TO START EDITING

### 1. Open Your Site:
- Double-click `pocky-blank-template.html`
- It opens in your browser

### 2. Login:
- Scroll to "🔒 Admin Login"
- Enter your password
- Click "Login"

### 3. Start Editing:
- Look at **bottom-right corner**
- You'll see a pink box: "👑 Admin Mode"
- Click **"Edit All Content"**
- A big popup appears with ALL your site content!

---

## ✏️ EDITING ALL CONTENT (THE EASY WAY)

When you click "Edit All Content", you get ONE big form with EVERYTHING:

### 🎨 HEADER SECTION:
- **Corner Text** - Top-left corner (e.g., "milk" or your name)
- **Main Title** - Big heading (e.g., "Pocky")
- **Subtitle** - Under main title (e.g., "The Super Snack")

### 🏠 HOME PAGE:
- **Section 1 Title** - Usually "Introduction"
- **Introduction Text** - Your welcome message
- **Section 2 Title** - Usually "Updates"

### 📖 ABOUT PAGE (3 sections):
- **Section 1**: Title + Content
- **Section 2**: Title + Content  
- **Section 3**: Title + Content

### 📋 RULES PAGE:
- **Section Title** - Usually "Rules"
- **Rules Content** - All your rules
  - Use `<br><br>` for blank lines
  - Use `<strong>text</strong>` for bold

### 💻 CODES PAGE:
- **Section Title** - Usually "Codes"
- **Codes Content** - Your codes/badges

### ✉️ JOIN PAGE:
- **Section Title** - Usually "Join"
- **Instructions** - Text above the form
- **Form Field Labels**:
  - Field 1 (usually "name")
  - Field 2 (usually "email")
  - Field 3 (usually "website url")
  - Field 4 (custom - you choose!)
  - Field 5 (custom - you choose!)
  - Field 6 (usually "comments")
- **Footer Text** - Below the form

### 👥 MEMBERS PAGE:
- **Section Title** - Usually "Members"

### ℹ️ SITE INFO PAGE (4 sections):
- **Section 1**: Title + Content (usually "Contact")
- **Section 2**: Title + Content (usually "Affiliates")
- **Section 3**: Title + Content (usually "Links")
- **Section 4**: Title + Content (usually "Copyrights")

### 🧭 NAVIGATION:
- **Link 1** - Usually "about"
- **Link 2** - Usually "rules"
- **Link 3** - Usually "codes"
- **Link 4** - Usually "join"
- **Link 5** - Usually "members"
- **Link 6** - Usually "site"
- **Link 7** - Usually "clear" (home button)

---

## 💾 SAVING YOUR CHANGES

### When Editing All Content:
1. Make all your changes
2. Scroll to the bottom
3. Click **"💾 SAVE ALL CHANGES"**
4. Wait for "✅ All changes saved!" message
5. Click "Close"

**Changes apply instantly!**

---

## 📝 POSTING UPDATES

### Text-Only Update:
1. Make sure you're logged in
2. Find the pink "Admin: Add New Update" panel
3. Type the **date** (e.g., "2/15/26")
4. Type your **update message**
5. Click **"Post Update"**

### Update With Image:
1. Type the date and message
2. Click **"📷 Add Image (Optional)"**
3. Choose an image from your computer
4. See the preview
5. Click **"Post Update"**

### Deleting Updates:
- Each update has a red **"Delete"** button
- Click it → Confirm → Gone!

---

## 📄 FORMATTING TIPS

### Line Breaks:
- Type `<br>` for single line break
- Type `<br><br>` for blank line

### Bold Text:
- Type `<strong>your text</strong>`

### Links:
- Type `<a href="http://website.com">link text</a>`

### Example:
```
Welcome to my site!<br><br>

This is <strong>bold text</strong>.<br>
Visit <a href="http://google.com">Google</a> for more info.
```

---

## 🎯 QUICK START WORKFLOW

### First Time Setup:
1. ✅ Change password in the HTML file
2. ✅ Open site in browser
3. ✅ Login with new password
4. ✅ Click "Edit All Content"
5. ✅ Fill in ALL the fields with your content
6. ✅ Click "SAVE ALL CHANGES"
7. ✅ Post your first update!

### Daily Use:
1. Open site
2. Login
3. Post updates with images
4. Or click "Edit All Content" to change text

---

## 💡 TIPS & TRICKS

### ✨ Best Practices:
- **Write your content in Notepad first** - then copy/paste into the editor
- **Save often** - click "SAVE ALL CHANGES" frequently
- **Preview before saving** - read through your changes
- **Keep it simple** - don't over-format with too many `<br>` tags

### 📱 Mobile Editing:
- You CAN edit from your phone!
- Login works the same
- "Edit All Content" button works
- Posting updates works
- Image uploads work

### 🔄 Starting Over:
- Clear your browser data to reset
- Or edit the HTML file and remove saved content manually

---

## 🆘 TROUBLESHOOTING

**"I can't find the Edit All Content button"**
- Make sure you're logged in first
- Look at bottom-right corner of screen
- Pink box should appear when logged in

**"My changes disappeared"**
- Did you click "SAVE ALL CHANGES"?
- Did you clear your browser data?
- Always save before closing!

**"I messed up the formatting"**
- Open the Edit All Content popup
- Find the broken section
- Remove any weird `<>` tags
- Save again

**"I forgot what I named a section"**
- Just open "Edit All Content"
- All current names are shown
- Change them if needed

**"Can I add more sections?"**
- No, not without editing code
- But you can use the existing 4 sections on Site Info page creatively

**"Can I change colors/fonts?"**
- Not through the editor
- You'd need to edit the CSS code directly
- Ask a developer friend if needed

---

## 📊 CONTENT ORGANIZATION IDEAS

### About Page (3 sections):
- Section 1: "About [Topic]" - Main description
- Section 2: "Where to Find" - Resources/stores
- Section 3: "Why I Made This" - Personal story

### Site Info Page (4 sections):
- Section 1: "Contact" - Email/social media
- Section 2: "Affiliates" - Partner sites
- Section 3: "Links" - Related resources
- Section 4: "Credits" - Copyrights/thanks

### Join Form Fields:
- Field 1: Name
- Field 2: Email  
- Field 3: Website URL
- Field 4: "Favorite [thing]?"
- Field 5: "Is the code up yet?"
- Field 6: Comments

---

## 🌟 REMEMBER:

✅ **Login first** before posting updates  
✅ **"Edit All Content"** edits everything at once  
✅ **"SAVE ALL CHANGES"** must be clicked to save  
✅ **Updates auto-save** when you post them  
✅ **Images are embedded** - no external hosting needed  
✅ **Changes are permanent** - they save in your browser

---

## 🎉 YOU'RE ALL SET!

You now have a completely customizable site where you can edit:
- ✅ Every page title
- ✅ Every section heading  
- ✅ Every paragraph of text
- ✅ All form labels
- ✅ All navigation links
- ✅ Post updates with images

**All without touching a single line of code!**

---

## 📞 NEED HELP?

If you get stuck:
1. Re-read the relevant section above
2. Try closing and re-opening the site
3. Make sure you clicked "SAVE ALL CHANGES"
4. Check that you're logged in

**Have fun building your site!** 🎨✨
